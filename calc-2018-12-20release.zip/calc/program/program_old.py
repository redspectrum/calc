import argparse

#======================================

OPERATORS = {'+': (1, lambda x, y: x + y),
             '-': (1, lambda x, y: x - y),
             '*': (2, lambda x, y: x * y),
             '/': (2, lambda x, y: x / y)}


def eval_(formula):
    def parse(formula_string):
        number = ''
        for s in formula_string:
            if s in '1234567890.':
                number += s
            elif number:
                yield float(number)
                number = ''
            if s in OPERATORS or s in "()":
                yield s
        if number:
            yield float(number)

    def shunting_yard(parsed_formula):
        stack = []
        for token in parsed_formula:
            if token in OPERATORS:
                while stack and stack[-1] != "(" and OPERATORS[token][0] <= OPERATORS[stack[-1]][0]:
                    yield stack.pop()
                stack.append(token)
            elif token == ")":
                while stack:
                    x = stack.pop()
                    if x == "(":
                        break
                    yield x
            elif token == "(":
                stack.append(token)
            else:
                yield token
        while stack:
            yield stack.pop()

    def calc(polish):
        stack = []
        for token in polish:
            if token in OPERATORS:
                y, x = stack.pop(), stack.pop()
                stack.append(OPERATORS[token][1](x, y))
            else:
                stack.append(token)
        return stack[0]

    return calc(shunting_yard(parse(formula)))




#===========================================

import operator

def calc(expr):
    OPERATORS = {'+': operator.add, '-': operator.sub, '*': operator.mul, '/': operator.truediv}
    stack = [0]
    for token in expr.split(" "):
        if token in OPERATORS:
            op2, op1 = stack.pop(), stack.pop()
            stack.append(OPERATORS[token](op1,op2))
        elif token:
            stack.append(float(token))
    return stack.pop()




# Addition function
def add(a, b):
    val = a + b
    return val


# Subtraction function
def sub(a, b):
    val = a - b
    return val


# Division function
def div(a, b):
    val = a / b
    return val


# Multiplication function
def multi(a, b):
    val = a * b
    return val


# Main function
def main():
    parser = argparse.ArgumentParser()

    group = parser.add_mutually_exclusive_group()
    group.add_argument("-fa", "--fadd", help="Performs addition", action="store_true")
    group.add_argument("-fs", "--fsub", help="Performs subtraction", action="store_true")
    group.add_argument("-fd", "--fdiv", help="Performs division", action="store_true")
    group.add_argument("-fm", "--fmulti", help="Performs multiplication", action="store_true")
    group.add_argument("--day", "-d", type=int, default=7,
                   help="Количество дней, прошедших с даты в названии папки(для удаления)")
    group.add_argument("-m MODULE [MODULE ...]", help="--use-modules MODULE [MODULE ...] additional modules to use", action="store_true")


    # parser.add_argument("num1", help="Number1 to calculate", type=int)
    # parser.add_argument("num2", help="Number2 to calculate", type=int)
    parser.add_argument("EXPRESSION", help="expression string to evaluate", type=str)




    args = parser.parse_args()

    print(eval_(args.EXPRESSION))


if __name__ == '__main__':
    main()
    # python setup.py install