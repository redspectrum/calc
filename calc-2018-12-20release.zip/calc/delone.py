a=str()
b=float()
c=bool()
d=complex()
d=2+3j
e=int

a1=list()
b1=[]
c1=tuple() # неизменяемый
d1=()
e1=set
f1=dict

print(type(a1))

q=[9,2,3,4,5,6,7,8]

def buble(list,number):
    high=len(list)-1
    low=0
    while low<=high:
        mid=(high+low)//2

        guess=list[mid]
        if guess==number:
            return mid
        elif guess<number:
            low=mid+1
        else:
            high=mid-1
    return None

print(buble(q,8))

print('one'.encode())
print(b'one'.decode())

a=[{'age':10},{'age':20},{'age':15}]

a.sort(key= lambda a: a['age'])
print(a)

f=lambda x, y: x+y

print(f(2,3))

a=['a','b','c']
b=[1,2,3]

di=dict(zip(a,b))
print('='*30)

a=[1,2,3,4,5,6,7,8,9,0,-1,-4,3,4,10]

def find_min(arr):
    res_min=arr[0]
    index_min=0
    for i in range(1,len(arr)):
        if res_min>arr[i]:
            res_min=arr[i]
            index_min=i
    return index_min

def sort_min(arr):
    res_arr=[]
    for i in range(len(arr)):
        res_arr.append(arr.pop(find_min(arr)))

    return res_arr

print(sort_min(a))

print(a.pop(0))











