import math

OPERATORS = {'+': (1, lambda x, y: x + y),
             '-': (1, lambda x, y: x - y),
             '*': (2, lambda x, y: x * y),
             '/': (2, lambda x, y: x / y),
             '%': (2, lambda x, y: x % y),
             '^': (3, lambda x, y: x ** y),
             }
# +, -, *, /, //,%, ^     how??  //


constant={'pi': math.pi,
       'e': math.e,
       }

opers={'sin':1000,
       'cos':(2, lambda x: math.cos(x))}


'pi+sin(30)+sinh(23)+sqrt(23)+1//2'

math_func=['acos', 'acosh', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'ceil', 'copysign', 'cos', 'cosh', 'degrees',
           'e', 'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'gcd',
           'hypot', 'inf', 'isclose', 'isfinite', 'isinf', 'isnan', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2',
           'modf', 'nan', 'pi', 'pow', 'radians', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'tau', 'trunc']



sin(25+5) ===> sn&30

def main(formula):

    def parse(formula_string):  #'sin(45)+33+4*2'
        number = ''
        for s in formula_string:
            print('s=', s)
            if s in '1234567890.':
                number += s
            elif s.isalpha():
                number += s

            elif number.isdigit():
                yield float(number)
                number = ''

            elif number in opers:
                yield opers.get(number)
                number = ''

            if s in OPERATORS or s in "()":
                yield s


        if number in constant:
            print(constant.get(number))
            yield constant.get(number)

        elif number.isdigit():
            yield float(number)

    def shunting_yard(parsed_formula):

        stack = []
        for token in parsed_formula:
            if token in OPERATORS:
                while stack and stack[-1] != "(" and OPERATORS[token][0] <= OPERATORS[stack[-1]][0]:
                    yield stack.pop()
                stack.append(token)
            elif token == ")":
                while stack:
                    x = stack.pop()
                    if x == "(":
                        break
                    yield x
            elif token == "(":
                stack.append(token)
            else:
                yield token
        while stack:
            yield stack.pop()

    def calc(polish):

        stack = []
        for token in polish:
            if token in OPERATORS:
                y, x = stack.pop(), stack.pop()
                stack.append(OPERATORS[token][1](x, y))
            else:
                stack.append(token)
        return stack[0]

    return calc(shunting_yard(parse(formula)))

#===========================================




if __name__ == '__main__':
    # print(math.sin(30))
    # print(math.pi)
    # print(math.e)
    #
    # print(1==1.0)
    #
    # print(abs(-2.5))
    # print(round(-2.5))


    # print(main('2*8^2'))
    # print(main('4+2*3'))
    # print(main('(6+10-4)/(1+1*2)+1'))

    # assert math.pi == main('pi+0')
    print(main("pi+2"))



'''
Арифметика (+, -, *, /, //,%, ^) (^ - степень).
Сравнение (<, <=, ==,! =,> =,>).
2 встроенных функции python: abs и round.
Все функции и константы из стандартного математического модуля python (тригонометрия, логарифмы,
так далее.).


Mathematical operations calculator must support
Arithmetic (+, -, *, /, //, %, ^) (^ is a power).
Comparison (<, <=, ==, !=, >=, >).
2 built-in python functions: abs and round.
All functions and constants from standard python module math (trigonometry, logarithms,
etc.).

   Non-functional requirements
It is mandatory to use argparse module.
Codebase must be covered with unittests with at least 70% coverage.
Usage of eval and exec is prohibited.
'''
