import queue


q=queue.Queue()

q.put(5)
q.put([1,2,3,4,5,6,7,8,9])
q.put('dfvdfv')

print(q.get())
print(q.get())
print(q.qsize())
print(q.empty())