
import argparse
#======================================
import math
import re

OPERATORS = {'+': (1, lambda x, y: x + y),
             '-': (1, lambda x, y: x - y),
             '*': (2, lambda x, y: x * y),
             '/': (2, lambda x, y: x / y),
             '//': (2, lambda x, y: x // y),
             '%': (2, lambda x, y: x % y),
             '^': (4, lambda x, y: x ** y),
             'acos':(3, lambda x: math.acos(x)),
             'cos': (3, lambda x: math.cos(x)),
             'sin': (3, lambda x: math.sin(x)),
             'sinh': (3, lambda x: math.sinh(x)),
             'pow': (3, lambda x, y: math.pow(x, y)),
             'log': (3, lambda x, y: math.log(x, y)),
             'log10': (3, lambda x: math.log10(x)),
            'log1p': (3, lambda x: math.log1p(x)),
             'abs': (3, lambda x: abs(x)),
             'round': (3, lambda x: round(x)),
             }



constant={'pi': math.pi,
          'e': math.e,
       }


OPERATORS_func=['acos', 'acosh', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'ceil', 'copysign', 'cos', 'cosh', 'degrees',
           'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'gcd',
           'hypot', 'inf', 'isclose', 'isfinite', 'isinf', 'isnan', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2',
           'modf', 'nan', 'pow', 'radians', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'tau', 'trunc', 'round',
            'abs','+', '-', '*', '/', '%', '^', '//', '(', ')', 'e', 'pi']

OPERATORS_double = ['+', '-', '*', '/', '%', '^', '//','%', 'log']

OPERATORS_compare = {'==': (lambda x, y: x == y),
                     '>=': (lambda x, y: x >= y),
                     '<=': (lambda x, y: x <= y),
                     '!=': (lambda x, y: x != y),
                     '<': (lambda x, y: x < y),
                     '>': (lambda x, y: x > y),
                     }


# math_func={'acos', 'acosh', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'ceil', 'copysign', 'cos', 'cosh', 'degrees',
#            'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'gcd',
#            'hypot', 'inf', 'isclose', 'isfinite', 'isinf', 'isnan', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2',
#            'modf', 'nan', 'pow', 'radians', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'tau', 'trunc', 'round'}



def main_count(formula):


    def check_error(formula):

        if not formula:
            return "ERROR: brackets are not balanced"
        else:

            if formula[-1] in OPERATORS:
                return "ERROR: brackets are not balanced"
            if formula[0] in '^%*/= |\\':
                return "ERROR: brackets are not balanced"

            if re.search(r'\d\s\d', formula):
                return "ERROR: brackets are not balanced"

            if formula.count('(') != formula.count(')'):
                return "ERROR: brackets are not balanced"

            if formula in OPERATORS:
                return "ERROR: brackets are not balanced"

            if re.search(r'[*,/,<,>,%,^,=]\s[*,/,<,>,%,^,=]', formula):
                return "ERROR: brackets are not balanced"

            if re.search(r'log[1,2][0,p][^(]', formula):
                return "ERROR: brackets are not balanced"


            for name_func in OPERATORS:
                if name_func.isalpha() or name_func in ['log1p', 'log10', 'atan2', 'expm1', 'log2']:
                    name_func_bracket = '{}('.format(name_func)


                    if name_func_bracket in formula:

                        for value in formula.split(name_func_bracket)[1:]:
                            count_brackets = 0

                            count_arguments = 0
                            for key in value:
                                if key == ',' and not count_brackets:
                                    count_arguments+=1

                                if key == ')' and not count_brackets:
                                    break
                                elif key == ')':
                                    count_brackets -= 1
                                elif key == '(':
                                    count_brackets += 1

                            if count_arguments > 1 and name_func=='log':
                                return "ERROR: brackets are not balanced"
                            elif (count_arguments > 1 or count_arguments==0) and name_func=='pow':
                                return "ERROR: brackets are not balanced"
                            elif count_arguments > 0 and not name_func in ['pow', 'log']:
                                return "ERROR: brackets are not balanced"

    def function_format(formula, name_function):
        # print(formula, name_function)

        # 'e^log(cos(3.0+log10(e^-e))'
        result_formula = formula


        first_argument = []
        second_argument = []
        count_argument = True
        count_bracket = 0
        for key in (name_function).join(formula.split('{}'.format(name_function))[1:]):

            if key == '(':
                count_bracket += 1
            if key == ')':
                count_bracket -= 1
            if key == ',':
                first_argument.pop(0)
                count_argument = False

            if key == ')' and not count_bracket and not count_argument:
                break
            elif key == ')' and not count_bracket:
                first_argument.append(key)
                break

            elif count_argument:
                first_argument.append(key)

            else:
                if key != ',':
                    second_argument.append(key)

        # print(''.join(first_argument), ''.join(second_argument))

        if not second_argument:
            second_argument.append('e')
            replace_expression = "{}{}".format(name_function, ''.join(first_argument),1)
        else:
            replace_expression = "{}({},{})".format(name_function, ''.join(first_argument),
                                                    ''.join(second_argument),1)


        x = main_count(''.join(first_argument))
        y = main_count(''.join(second_argument))


        result_function = OPERATORS[name_function][1](x, y)

        result_formula = result_formula.replace(replace_expression, str(result_function),1)

        # check twice function FE: pow pow

        if name_function=='log':
            if 'log(' in result_formula:
                result_formula=function_format(result_formula, name_function)
        else:
            if name_function in result_formula:
                result_formula=function_format(result_formula, name_function)

        return result_formula

    def format_degree(formula):
        if '^^' in formula:
            raise SyntaxError
        result_formula=[]

        for i,key in enumerate(formula.split('^')):

            result_formula.append(key)
            if i != len(formula.split('^'))-1:
                result_formula.append('^'*(i+1))
                OPERATORS.update({'^'*(i+1): (4+i, lambda x, y: x ** y)})
                OPERATORS_double.append('^'*(i+1))
                OPERATORS_func.append('^'*(i+1))

        return ''.join(result_formula)

    def function_format_degree_replace_function(formula):
        # replace 1^sin(pi) into==> 1^(sin(pi))

        expression = []
        count_argument = False
        count_bracket = 0
        for i, key in enumerate(formula):

            if key == '(':
                count_bracket += 1
            elif key == ')':
                count_bracket -= 1

            if count_argument:
                expression.append(key)

            if key == ')' and not count_bracket and count_argument:
                break

            if key == '^' and formula[i + 1].isalpha():
                count_argument = True

        formula = formula.replace("{}".format(''.join(expression)), "({})".format(''.join(expression)), 1)

        count = False
        for i, key in enumerate(formula):
            if key == '^' and formula[i + 1].isalpha():
                count = True
                break

        if count:
            formula = function_format_degree_replace_function(formula)

        return formula

    def replace_degree_negative_number(formula):

        # replace  ^-5 ==> into ^(0-5)
        # ^ -e == > into ^(0 - e)
        # ^ -cos() == > into ^(0 - cos())
        # ^ -(1+2) == > into ^(0 - (1+2))

        expression=[]
        count=False
        bracket_count = 0
        for i,key in enumerate(formula):


            if count:
                if key == ')' and not bracket_count:
                    expression.append(key)
                    break
                elif key == ')':
                    bracket_count -= 1
                elif key == '(':
                    bracket_count += 1

                if expression and (key in OPERATORS_double or key in OPERATORS_compare) and not bracket_count:
                    break
                else:
                    expression.append(key)


            if key=='^' and formula[i+1]=='-':
                count=True


        # replace only first expression
        formula = formula.replace(("^{}".format(''.join(expression)))  ,    "^(0{})".format(''.join(expression)),1)

        if '^-' in formula:
            formula=replace_degree_negative_number(formula)

        return formula


    def delete_same_signs(formula):

        new_data = []

        # delete backspace
        formula=formula.replace(' ', '')


        formula='(0-'.join(formula.split('(-'))


        for name_function in ['pow', 'log(', 'copysign', 'ldexp', 'atan2', 'hypot']:
            if name_function in formula:
                # because we use only log (without log10,log1p)
                if name_function=='log(':
                    name_function='log'
                formula=function_format(formula, name_function)


        for _ in formula:
            if '^' in formula and formula[formula.index('^')+1].isalpha():
                formula = function_format_degree_replace_function(formula)
                break


        if formula.count("^") > 1:
            formula=format_degree(formula)

        new_data.append(formula[0])

        for token in formula[1:]:
            if new_data[-1] == '+' and token == '-':
                new_data[-1] = '-'
            elif new_data[-1] == '-' and token == '+':
                new_data[-1] = '-'
            elif new_data[-1] == '-' and token == '-':
                new_data[-1] = '+'
            elif new_data[-1] == '+' and token == '+':
                new_data[-1] = '+'
            else:
                new_data.append(token)
        if new_data[0]=='-':
            new_data.insert(0,'0')
        if new_data[0]=='+':
            new_data.pop(0)

        formula = ''.join(new_data)

        # replace 5/-1 into 5*(-1)/1
        formula = formula.replace('/-','*(0-1)/')
        formula = formula.replace('*-','*(0-1)*')

        if '^-' in formula:
            formula=replace_degree_negative_number(formula)

        return formula

    def parse(formula_string):
        # print(formula_string)

        stack = []

        for i, key in enumerate(formula_string):

            if key in '1234567890.':

                # check log10 log1p log2
                if len(stack) > 2 and ''.join(stack[:3])=='log':

                    stack.append(key)
                    if ''.join(stack) in OPERATORS_func:
                        yield ''.join(stack)
                        stack = []


                elif stack and (stack[0] not in '1234567890.'):
                    yield ''.join(stack)
                    stack = []
                    stack.append(key)
                else:
                    stack.append(key)

            else:
                if key in '()':
                    if stack and (stack[0] in '1234567890.'):
                        yield float(''.join(stack))
                    elif stack:
                        yield ''.join(stack)

                    stack = []
                    stack.append(key)


                elif len(stack) > 2 and ''.join(stack[:3])=='log':
                    stack.append(key)
                    if ''.join(stack) in OPERATORS_func:
                        yield ''.join(stack)
                        stack = []


                elif stack and stack[0] in '1234567890.':
                    yield float(''.join(stack))
                    stack = []
                    stack.append(key)

                else:

                    if ''.join(stack) + key in OPERATORS_func:
                        stack.append(key)

                    elif ''.join(stack) in constant:
                        yield constant.get(''.join(stack))
                        stack = []
                        stack.append(key)


                    elif ''.join(stack) in OPERATORS_func:

                        yield ''.join(stack)
                        stack = []
                        stack.append(key)
                    else:
                        stack.append(key)
        else:

            if stack and (stack[0] in '1234567890.'):
                yield float(''.join(stack))
            elif ''.join(stack) in constant:
                yield constant.get(''.join(stack))
            else:
                yield ''.join(stack)


    def shunting_yard(parsed_formula):
        #print(list(parsed_formula))


        stack = []
        for token in parsed_formula:
            if token in constant:
                token = constant.get(''.join(token))


            if token in OPERATORS:
                while stack and stack[-1] != "(" and OPERATORS[token][0] <= OPERATORS[stack[-1]][0]:
                    yield stack.pop()
                stack.append(token)
            elif token == ")":
                while stack:
                    x = stack.pop()
                    if x == "(":
                        break
                    yield x
            elif token == "(":
                stack.append(token)
            else:
                yield token
        while stack:
            yield stack.pop()


    def calc(polish):
        #print(list(polish))

        stack = []

        for token in polish:

            if token in OPERATORS:

                if token in OPERATORS_double:
                    # print('token,stack ',token,stack)

                    y, x = stack.pop(), stack.pop()

                    stack.append(OPERATORS[token][1](x, y))
                else:
                    x = stack.pop()

                    stack.append(OPERATORS[token][1](x))
            else:
                stack.append(token)

        return stack[0]

    def check_compare(formula):
        for compare in OPERATORS_compare:
            if compare in formula:
                return OPERATORS_compare.get(compare)(
                    main_count(formula.split(compare)[0]),
                    main_count(formula.split(compare)[1]))

        # start calculation
        return calc(shunting_yard(parse(delete_same_signs(formula))))


    return check_error(formula) if check_error(formula) else check_compare(formula)



if __name__ == '__main__':
    data=[
    # "pow(2, 3, 4)",
    # "1+2*4/3+1!=1+2*4/3+2",                          #| Result: FAIL: Invalid output:  | Expected: True",
    "==7",                                    #| Result: FAIL: Invalid output:  | Expected: False",
    "5 > = 6",  #True




    # "==7",
    # "1 + 2(3 * 4))",
    # "((1+2)",
    # "1 + 1 2 3 4 5 6 ",
    # "abs",
    # "(((((",
    # "------",
    # "5 > = 6",
    # "5 / / 6",
    # "6 < = 6",
    # "6 * * 6",
    # "==7",
    # "log10099(100)",
    # "log10(100)",
    # "log1p(100)",
    # "log(100)",
        # "10(2+1)",
        # "(1 + 2)(3 + 4)",
    # "epi": e * pi,
    # "2sin(pi/2)": 2 * sin(pi / 2),
    # "2 sin(pi/2)": 2 * sin(pi / 2),
    # "sin(pi)sin(pi) + cos(pi)cos(pi)": sin(pi) * sin(pi) + cos(pi) * cos(pi),





    #     sin(e ^ log(e ^ e ^ sin(23.0), 45.0) + cos(3.0 + log10(e ^ -e))) | Result: FAIL: Invalid
    # output: 0.9944893785636455
    #         | Expected: 0.76638122986603

          # '(2.0^(pi/pi+e/e+2.0^0.0))',  # Expected: 8.0
          # '10*e^0*log10(.4 -5/ -0.1-10) - -abs(-53/10) + -5', # 16
          # 'sin(pi/2^1) + log(1*4+2^2+1, 3^2)',  #| Expected: 2.0


          # '2*sin(pi/2)',
        # 'log10(100)+log1p(10)'
        #     '1+pow(2,3)-2'
        #   '2^(1+2)^3',

          # 'pow(2, 3)',
          # 'log(10)+log10(100)+log2(1)+log1p(2)'

          ]


    # math.log(10, 100)
    # math.copysign(X, Y)
    # math.ldexp(X, I)
    # math.pow(X, Y)
    # math.atan2(Y, X)
    # math.hypot(X, Y)


    for value in data:
        print(main_count(value))

