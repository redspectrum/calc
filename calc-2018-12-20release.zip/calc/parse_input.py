from math import *

def bar(string):
    sign=[]

    for i,key in enumerate(string):

        if key.isdigit() or key=='.':
            if sign:
                if sign[0].isdigit() or sign[0]=='.':
                    sign.append(key)
                else:
                    yield ''.join(sign)
                    sign=[]
                    sign.append(key)
            else:
                sign.append(key)

        elif key.isalpha():
            if sign:
                if sign[0].isalpha():
                    sign.append(key)
                else:
                    yield ''.join(sign)
                    sign=[]
                    sign.append(key)
            else:
                sign.append(key)

        elif key in ['(',')']:
            if sign:
                yield ''.join(sign)
                sign=[]
                sign.append(key)
            else:
                sign.append(key)

        else:
            if sign and sign[0].isdigit() or sign[0] == '.' or sign[0].isalpha() \
                    or sign[0] in ['(',')']:
                yield ''.join(sign)
                sign = []
            sign.append(key)

    else:
        yield ''.join(sign)



def check(str):
    pass

def myformat(express):


    if express[0]=='-' or express[0]=='+':
        express='0{}'.format(express)

    return express










if __name__ == '__main__':
    k=bar('(12.3=>3)-+---+cos(1\\pi)')

    # for i in k:
    #     print(i)

    print(myformat('-----1'))




    data='--123-++---780'
    # OPTIONAL REQUIREMENTS
    IMPLICIT_MULTIPLICATION = {
        "10(2+1)": 10*(2+1),
        "(1 + 2)(3 + 4)": (1 + 2) * (3 + 4),
        "epi": e * pi,
        "2sin(pi/2)": 2 * sin(pi/2),
        "2 sin(pi/2)": 2 * sin(pi/2),
        "sin(pi)sin(pi) + cos(pi)cos(pi)": sin(pi) * sin(pi) + cos(pi) * cos(pi),
    }

