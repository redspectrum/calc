import math

OPERATORS = {'+': (1, lambda x, y: x + y),
             '-': (1, lambda x, y: x - y),
             '*': (2, lambda x, y: x * y),
             '/': (2, lambda x, y: x / y),
             '//': (2, lambda x, y: x // y),
             '%': (2, lambda x, y: x % y),
             '^': (4, lambda x, y: x ** y),
             'acos':(3, lambda x: math.acos(x)),
             'cos': (3, lambda x: math.cos(x)),
             'sin': (3, lambda x: math.sin(x)),
             'sinh': (3, lambda x: math.sinh(x)),
             'log': (3, lambda x: math.log(x)),
             'log10': (3, lambda x: math.log10(x)),
            'log1p': (3, lambda x: math.log1p(x)),
             'abs': (3, lambda x: abs(x)),
             'round': (3, lambda x: round(x)),
             }

constant={'pi': math.pi,
          'e': math.e,
       }


OPERATORS_func={'acos', 'acosh', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'ceil', 'copysign', 'cos', 'cosh', 'degrees',
           'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'gcd',
           'hypot', 'inf', 'isclose', 'isfinite', 'isinf', 'isnan', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2',
           'modf', 'nan', 'pow', 'radians', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'tau', 'trunc', 'round',
            'abs','+', '-', '*', '/', '%', '^', '//', '(', ')','logten'}

OPERATORS_double = {'+', '-', '*', '/', '%', '^', '//','%','^'}



# math_func={'acos', 'acosh', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'ceil', 'copysign', 'cos', 'cosh', 'degrees',
#            'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'gcd',
#            'hypot', 'inf', 'isclose', 'isfinite', 'isinf', 'isnan', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2',
#            'modf', 'nan', 'pow', 'radians', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'tau', 'trunc', 'round'}


def main_count(formula):
    def pow_format(formula):
        result_formula = formula

        for data in formula.split('pow(')[1:]:
            first_argument = []
            second_argument = []
            count_argument = True
            count_bracket = 0
            for key in data:
                if key == ',':
                    count_argument = False
                elif count_argument:
                    first_argument.append(key)
                else:
                    if key == ')' and not count_bracket:
                        break
                    else:
                        if key == '(':
                            count_bracket += 1
                        if key == ')':
                            count_bracket -= 1
                        second_argument.append(key)

            result_formula = result_formula.replace(
                "pow({},{})".format(''.join(first_argument), ''.join(second_argument)),
                "({})^({})".format(''.join(first_argument), ''.join(second_argument)))

        return result_formula



    def delete_same_signs(formula):
        new_data = []

        # delete backspace
        formula=formula.replace(' ', '')

        formula='(0-'.join(formula.split('(-'))

        if 'pow' in formula:
            formula=pow_format(formula)

        new_data.append(formula[0])

        for token in formula[1:]:
            if new_data[-1] == '+' and token == '-':
                new_data[-1] = '-'
            elif new_data[-1] == '-' and token == '+':
                new_data[-1] = '-'
            elif new_data[-1] == '-' and token == '-':
                new_data[-1] = '+'
            elif new_data[-1] == '+' and token == '+':
                new_data[-1] = '+'
            else:
                new_data.append(token)
        if new_data[0]=='-':
            new_data.insert(0,'0')
        if new_data[0]=='+':
            new_data.pop(0)



        return ''.join(new_data)

    def parse(formula_string):
        stack = []

        for i, key in enumerate(formula_string):

            if key in '1234567890.':
                # check log10 log1p log2
                if len(stack) > 2 and ''.join(stack[:3])=='log':
                    stack.append(key)
                    if ''.join(stack) in OPERATORS_func:
                        yield ''.join(stack)
                        stack = []




                elif stack and (stack[0] not in '1234567890.'):
                    yield ''.join(stack)
                    stack = []
                    stack.append(key)
                else:
                    stack.append(key)

            else:
                if len(stack) > 2 and ''.join(stack[:3])=='log':
                    stack.append(key)
                    if ''.join(stack) in OPERATORS_func:
                        yield ''.join(stack)
                        stack = []


                elif stack and stack[0] in '1234567890.':
                    yield float(''.join(stack))
                    stack = []
                    stack.append(key)

                else:

                    if ''.join(stack) + key in OPERATORS_func:
                        stack.append(key)

                    elif ''.join(stack) in constant:
                        yield constant.get(''.join(stack))
                        stack = []
                        stack.append(key)


                    elif ''.join(stack) in OPERATORS_func:

                        yield ''.join(stack)
                        stack = []
                        stack.append(key)
                    else:
                        stack.append(key)
        else:

            if stack and (stack[0] in '1234567890.'):
                yield float(''.join(stack))
            elif ''.join(stack) in constant:
                yield constant.get(''.join(stack))
            else:
                yield ''.join(stack)

    def shunting_yard(parsed_formula):
        # print(list(parsed_formula))

        stack = []
        for token in parsed_formula:
            if token in OPERATORS:
                while stack and stack[-1] != "(" and OPERATORS[token][0] <= OPERATORS[stack[-1]][0]:
                    yield stack.pop()
                stack.append(token)
            elif token == ")":
                while stack:
                    x = stack.pop()
                    if x == "(":
                        break
                    yield x
            elif token == "(":
                stack.append(token)
            else:
                yield token
        while stack:
            yield stack.pop()


    def calc(polish):
        #print(list(polish))

        stack = []

        for token in polish:

            if token in OPERATORS:
                if token in OPERATORS_double:
                    y, x = stack.pop(), stack.pop()
                    stack.append(OPERATORS[token][1](x, y))
                else:
                    x = stack.pop()
                    stack.append(OPERATORS[token][1](x))
            else:
                stack.append(token)

        return stack[0]




    return calc(shunting_yard(parse(delete_same_signs(formula))))



if __name__ == '__main__':
    data=[
          # 'abs(-5)',
          # '2^3^4^5',
          # 'sin(pi/2^1)',
          # 'pi+e',
          # 'sin(pi/2)*111*6',
          # '2*sin(pi/2)',
        # 'log10(100)+log1p(10)'
            '1+pow(2,3)-2'
          # '2^(1+2)^4',

          # 'pow(2, 3)',
          # 'log(10)+log10(100)+log2(1)+log1p(2)'

          ]


    for value in data:
        print(main_count(value))

