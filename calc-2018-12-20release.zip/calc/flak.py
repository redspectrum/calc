def foo(one):
    for i in range(one):
        print(i)


foo(2)