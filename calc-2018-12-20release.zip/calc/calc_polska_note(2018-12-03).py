# import pdb
#
#
# OPERATORS = {'+': (1, lambda x, y: x + y),
#              '-': (1, lambda x, y: x - y),
#              '*': (2, lambda x, y: x * y),
#              '/': (2, lambda x, y: x / y)}
#
#
#
# f=lambda x, y: x ** y
#
# a=6
# print('hello')
# pdb.set_trace()
# print(f(a,2))
#
# print(f(a,3))


# data='11111111111'
#
# def foo(data):
#
#     for i in data:
#         if int(i)%2==0:
#             print('enter')
#             yield i
#         print('no')
#     print('hi')
#
# def bar(stack):
#     while stack:
#         yield stack.pop()
#
# value=[1,2,3]
#
# k=bar(value)
#
# # k=foo(data)
# print('gen=',next(k))
# print('gen=',next(k))
# # print('gen=',next(k))
# # print('gen=',list(k))
# # print('gen=',next(k))

import math

OPERATORS = {'+': (1, lambda x, y: x + y),
             '-': (1, lambda x, y: x - y),
             '*': (2, lambda x, y: x * y),
             '/': (2, lambda x, y: x / y),
             '%': (2, lambda x, y: x % y),
             '^': (3, lambda x, y: x ** y),
             '~': (2, lambda x, y: x // y),
             'acos':(2, lambda x: math.acos(x)),
             'cos': (2, lambda x: math.cos(x)),
             }

math_func={'acos', 'acosh', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'ceil', 'copysign', 'cos', 'cosh', 'degrees',
           'e', 'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'gcd',
           'hypot', 'inf', 'isclose', 'isfinite', 'isinf', 'isnan', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2',
           'modf', 'nan', 'pi', 'pow', 'radians', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'tau', 'trunc'}

constant={'pi': math.pi,
          'e': math.e,
       }


def main_count(data=None):

    data = data.replace('//','~')

    new_data = []
    new_data.append(data[0])

    for token in data[1:]:
        if new_data[-1] == '+' and token == '-':
            new_data[-1] = '-'
        elif new_data[-1] == '-' and token == '+':
            new_data[-1] = '-'
        elif new_data[-1] == '-' and token == '-':
            new_data[-1] = '+'
        elif new_data[-1] == '+' and token == '+':
            new_data[-1] = '+'
        else:
            new_data.append(token)



    def parse(data):
        number=''
        func=''

        for s in data:
            if s in '1234567890.':
                number+=s
            elif number:
                yield float(number)
                number=''

            elif s.isalpha():
                func += s
            elif func:
                if func in constant:
                    yield constant.get(func)
                else:
                    yield func
                func=''

            if s in OPERATORS or s in "()":
                yield s

        if number:
            yield float(number)
        if func:
            if func in constant:
                yield constant.get(func)
            else:
                yield func



    def shunting_yard(parsed_formula):

        stack = []
        for token in parsed_formula:

            if token in OPERATORS:
                while stack and stack[-1] != "(" and OPERATORS[token][0] <= OPERATORS[stack[-1]][0]:
                    yield stack.pop()
                stack.append(token)
            elif token == ")":
                while stack:
                    x = stack.pop()
                    if x == "(":
                        break
                    yield x
            elif token == "(":
                stack.append(token)
            else:
                yield token
        while stack:
            yield stack.pop()


    # def calc(polish):
    #     return list(polish)

    # ['-', '-', '-', '-', '+', 3.0, '-']
    #

    def calc(polish):


        stack = []
        sign_change=False

        for token in polish:
            if token in OPERATORS:
                if token in math_func:
                    x = stack.pop()
                    stack.append(OPERATORS[token][1](x))
                else:
                    if len(stack)==0 and token=='-':
                        sign_change=True

                    elif len(stack)==1 and token=='-':
                        stack[0]=stack[0]*(-1)

                    elif len(stack)>1:
                        y, x = stack.pop(), stack.pop()
                        stack.append(OPERATORS[token][1](x, y))


            else:
                if sign_change:
                    stack.append(token*(-1))
                    sign_change = False
                else:
                    stack.append(token)

        return stack[0]

    return calc(shunting_yard(parse(new_data)))


if __name__ == '__main__':

    data = 'pi+sin(30)+sinh(23)+sqrt(23)+1//2'
    data = '6-(-13)'
    # data = '(6+10-4)/(1+1*2)+1'
    # data = '7//3'
    # data = '5*2+10'
    data='0---2'

    print(main_count(data))



















