import unittest

from delon import *


class MyListTest(unittest.TestCase):

    def test_normal(self):
        result = my_sort([4,5,6,34,566,7,8])
        self.assertEqual(result, [4, 5, 6, 7, 8, 34, 566])

    def test_negative(self):
        result = my_sort([4, -5, 6, -34, 566, 7, 8])
        self.assertEqual(result, [-34, -5, 4, 6, 7, 8, 566])

    def test_empty(self):
        result = my_sort([])
        self.assertEqual(result, [])

    def test_single(self):
        result = my_sort([4])
        self.assertEqual(result, [4])

    def test_sort1(self):
        result = my_sort([1])
        self.assertEqual(result, [1])

    # def test_sort2(self):
    #     result = my_sort([2])
    #     self.assertEqual(result, [2])

if __name__=='__main__':
    unittest.main()