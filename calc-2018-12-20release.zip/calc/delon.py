# # import pdb
# #
# #
# # OPERATORS = {'+': (1, lambda x, y: x + y),
# #              '-': (1, lambda x, y: x - y),
# #              '*': (2, lambda x, y: x * y),
# #              '/': (2, lambda x, y: x / y)}
# #
# #
# #
# # f=lambda x, y: x ** y
# #
# # a=6
# # print('hello')
# # pdb.set_trace()
# # print(f(a,2))
# #
# # print(f(a,3))
#
#
# # data='11111111111'
# #
# # def foo(data):
# #
# #     for i in data:
# #         if int(i)%2==0:
# #             print('enter')
# #             yield i
# #         print('no')
# #     print('hi')
# #
# # def bar(stack):
# #     while stack:
# #         yield stack.pop()
# #
# # value=[1,2,3]
# #
# # k=bar(value)
# #
# # # k=foo(data)
# # print('gen=',next(k))
# # print('gen=',next(k))
# # # print('gen=',next(k))
# # # print('gen=',list(k))
# # # print('gen=',next(k))
#
# import math
#
# OPERATORS = {'+': (1, lambda x, y: x + y),
#              '-': (1, lambda x, y: x - y),
#              '*': (2, lambda x, y: x * y),
#              '/': (2, lambda x, y: x / y),
#              '%': (2, lambda x, y: x % y),
#              '^': (3, lambda x, y: x ** y),
#              '~': (3, lambda x, y: x // y),
#              'cos':(2, lambda x: math.cos(x))
#              }
#
#
#
# math_func=['acos', 'acosh', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'ceil', 'copysign', 'cos', 'cosh', 'degrees',
#            'e', 'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'gcd',
#            'hypot', 'inf', 'isclose', 'isfinite', 'isinf', 'isnan', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2',
#            'modf', 'nan', 'pi', 'pow', 'radians', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'tau', 'trunc']
#
# constant={'pi': math.pi,
#           'e': math.e,
#        }
#
# def main(data=None):
#
#
#     data = data.replace('//','~')
#
#
#     # number=''
#     # func=''
#     # for s in data:
#     #     if s in '1234567890.':
#     #         number+=s
#     #     elif number:
#     #         print(number)
#     #         number=''
#     #
#     #     elif s.isalpha():
#     #         func += s
#     #     elif func:
#     #         print(func)
#     #         func=''
#     #
#     #     if s in OPERATORS or s in "()":
#     #         print(s)
#     #
#     # if number:
#     #     print(number)
#     # if func:
#     #     print(number)
#     #
#     def parse(data):
#         number=''
#         func=''
#
#         for s in data:
#             if s in '1234567890.':
#                 number+=s
#             elif number:
#                 yield float(number)
#                 number=''
#
#             elif s.isalpha():
#                 func += s
#             elif func:
#                 if func in constant:
#                     yield constant.get(func)
#                 else:
#                     yield func
#                 func=''
#
#             if s in OPERATORS or s in "()":
#                 yield s
#
#         if number:
#             yield float(number)
#         if func:
#             if func in constant:
#                 yield constant.get(func)
#             else:
#                 yield func
#
#
#
#     def shunting_yard(parsed_formula):
#
#         stack = []
#         for token in parsed_formula:
#
#             if token in OPERATORS:
#                 while stack and stack[-1] != "(" and OPERATORS[token][0] <= OPERATORS[stack[-1]][0]:
#                     yield stack.pop()
#                 stack.append(token)
#             elif token == ")":
#                 while stack:
#                     x = stack.pop()
#                     if x == "(":
#                         break
#                     yield x
#             elif token == "(":
#                 stack.append(token)
#             else:
#                 yield token
#         while stack:
#             yield stack.pop()
#
#
#     # def calc(polish):
#     #     return list(polish)
#
#     def calc(polish):
#
#         stack = []
#
#         for token in polish:
#             if token in OPERATORS:
#                 if token in math_func:
#                     x = stack.pop()
#                     stack.append(OPERATORS[token][1](x))
#                 else:
#                     y, x = stack.pop(), stack.pop()
#                     stack.append(OPERATORS[token][1](x, y))
#
#
#             else:
#                 stack.append(token)
#
#         return stack[0]
#
#
#     return calc(shunting_yard(parse(data)))
#
# #
# #
# # data = 'pi+sin(30)+sinh(23)+sqrt(23)+1//2'
# # data = 'pi+1'
# # # data = '(6+10-4)/(1+1*2)+1'
# # # data = '7//3'
# # # data = '5*2+10'
# # # data='cos(30)'
# #
# # print(main(data))
# #
#
# data='--123-++---780'
# new_data = []
# new_data.append(data[0])
#
# for token in data[1:]:
#     if new_data[-1]=='+' and token=='-':
#         new_data[-1]='-'
#     elif new_data[-1]=='-' and token=='+':
#         new_data[-1]='-'
#     elif new_data[-1]=='-' and token=='-':
#         new_data[-1]='+'
#     elif new_data[-1]=='+' and token=='+':
#         new_data[-1]='+'
#     else:
#         new_data.append(token)
#
# print(new_data)




#
#
#
# def one(formula_string):
#     # operations
#     # math
#     # number
#     # ()
#     stack=str
#     merge_token=[]
#
#     for key in formula_string:
#
#         if key.isdigit() or key=='.':
#             if stack != 'number':
#                 yield ''.join(merge_token)
#                 merge_token = []
#                 merge_token.append(key)
#                 stack = 'number'
#             else:
#                 merge_token.append(key)
#
#
#
#     if key in '()':
#         yield ''.join(merge_token)
#         yield key
#         merge_token = []
#         stack=None
#
#         if key in math_func:
#             if stack != 'math':
#                 yield ''.join(merge_token)
#                 merge_token = []
#                 merge_token.append(key)
#                 stack = 'math'
#             else:
#                 merge_token.append(key)
#
#
#
#
# def two(formula_string):
#     stack=[]
#
#     for i,key in enumerate(formula_string):
#
#         if key.isdigit() or key=='.':
#
#             if stack and (stack[0] not in '1234567890.'):
#                     yield ''.join(stack)
#                     stack=[]
#                     stack.append(key)
#             else:
#                 stack.append(key)
#
#         else:
#
#             if stack and stack[0] in '1234567890.':
#                 yield ''.join(stack)
#                 stack = []
#                 stack.append(key)
#             else:
#
#
#                 if ''.join(stack)+key in OPERATORS:
#                     stack.append(key)
#
#                 elif ''.join(stack) in OPERATORS:
#
#                     yield ''.join(stack)
#                     stack = []
#                     stack.append(key)
#                 else:
#                     stack.append(key)
#
#
#     else:
#         yield ''.join(stack)
#
#
#
# math_func={'acos', 'acosh'}
# OPERATORS = {'+': (1, lambda x, y: x + y),
#              '-': (1, lambda x, y: x - y),
#              'cos': (1, lambda x, y: x - y),
#              'acos': (1, lambda x, y: x - y),
#              'sin': (1, lambda x, y: x - y),
#              'asin': (1, lambda x, y: x - y),
#              'sinh': (1, lambda x, y: x - y),
#              '/': (1, lambda x, y: x - y),
#              '//': (1, lambda x, y: x - y),
#              'pi': (1, lambda x, y: x - y),
#              'e': (1, lambda x, y: x - y),
#              '(' : 1,
#              ')': 2
#              }
#
#
#
# formula_string = 'sin(pi/2^1)'
# # formula_string = 'pie'
#
# print(list(two(formula_string)))
#
# import math
#
# formula='2+pow(2,(3*7+5))+sin(pi)+pow(10,1)+3'
#
# 2**(3*7+5)
#
# def pow_format(formula):
#     result_formula=formula
#
#     for data in formula.split('pow(')[1:]:
#         first_argument = []
#         second_argument = []
#         count_argument=True
#         count_bracket=0
#         print('-----------------')
#         for key in data:
#             if key==',':
#                 count_argument=False
#             elif count_argument:
#                 first_argument.append(key)
#             else:
#                 if key==')' and not count_bracket:
#                     break
#                 else:
#                     if key=='(':
#                         count_bracket+=1
#                     if key==')':
#                         count_bracket-=1
#                     second_argument.append(key)
#
#
#         print(first_argument)
#         print(second_argument)
#         print("pow("+''.join(first_argument)+','+''.join(second_argument)+')')
#         result_formula=result_formula.replace("pow({},{})".format(''.join(first_argument),''.join(second_argument)),
#                                               "({})**({})".format(''.join(first_argument),''.join(second_argument)))
#
#     return result_formula
#
# if 'pow' in formula:
#     print(pow_format(formula))
#
# # print(math.pow(2,3)==2**3)
#
# ===================================================
# formula='1^(2+1)^3^5+9^2'
# # 1^2^3 ==> 1^((2)^(3))
#
# def format_degree(formula):
#     list_numbers=[]
#     count_bracket=0
#     count=False
#
#     for key in formula:
#         if count:
#             if key in "+-/*%":
#                 pass
#             else:
#                 list_numbers.append(key)
#
#         if key=='^':
#             count = True
#
#
#
#
#
# # if formula.count("^")>1:
# #     format_degree(formula)
# def summa(a):
#     return a
#
# formula='1==2'
#
# OPERATORS_compare = {'==': (lambda x, y: x == y),
#              '>=': (lambda x, y: x >= y),
#              '<=': (lambda x, y: x <= y),
#              '!=': (lambda x, y: x != y),
#              }
#
#
# def func_compare(formula):
#     for compare in OPERATORS_compare:
#         if compare in formula:
#             return OPERATORS_compare.get(compare)(summa(formula.split(compare)[0]), summa(formula.split(compare)[1]))
#
# # print(func_compare(formula))
#
# def function_format_degree_replace_function(formula):
#     # replace 1^sin(pi) into==> 1^(sin(pi))
#
#     expression = []
#     count_argument = False
#     count_bracket = 0
#     for i,key in enumerate(formula):
#
#         if key == '(':
#             count_bracket += 1
#         elif key == ')':
#             count_bracket -= 1
#
#
#         if count_argument:
#             expression.append(key)
#
#         if key == ')' and not count_bracket and count_argument:
#             break
#
#         if key=='^' and formula[i+1].isalpha():
#             count_argument = True
#
#
#     formula=formula.replace( "{}".format(''.join(expression)),"({})".format(''.join(expression)) ,1)
#
#
#
#     count = False
#     for i,key in enumerate(formula):
#         if key=='^' and formula[i+1].isalpha():
#             count=True
#             break
#
#     if count:
#         formula=function_format_degree_replace_function(formula)
#
#     return formula
#
#
# formula='2^4+1^sin(pi+23-(1^2))-1+2^log(20)'
# formula='1^sin(30)'
#
# for i,key in enumerate(formula):
#     if '^' in formula and formula[i+1].isalpha():
#         formula=function_format_degree_replace_function(formula)
#         break
#
# print(formula)
# formula='10^s(2+1)'
#
#
# for i, key in enumerate(formula):
#     if '^' in formula and formula[formula.index('^')+1].isalpha():
#         print(formula)
#         # formula = function_format_degree_replace_function(formula)
#         break
#
# OPERATORS = {'+': (1, lambda x, y: x + y),
#              '-': (1, lambda x, y: x - y),
#              '*': (2, lambda x, y: x * y),
#              '/': (2, lambda x, y: x / y),
#              '//': (2, lambda x, y: x // y),
#              '%': (2, lambda x, y: x % y),
#              '^': (4, lambda x, y: x ** y),
#              'acos':(3, lambda x: math.acos(x)),
#              'cos': (3, lambda x: math.cos(x)),
#              'sin': (3, lambda x: math.sin(x)),
#              'sinh': (3, lambda x: math.sinh(x)),
#              'pow': (3, lambda x, y: math.pow(x, y)),
#              'log': (3, lambda x, y: math.log(x, y)),
#              'log10': (3, lambda x: math.log10(x)),
#             'log1p': (3, lambda x: math.log1p(x)),
#              'abs': (3, lambda x: abs(x)),
#              'round': (3, lambda x: round(x)),
#              }
# OPERATORS_func=['acos', 'acosh', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'ceil', 'copysign', 'cos', 'cosh', 'degrees',
#            'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'gcd',
#            'hypot', 'inf', 'isclose', 'isfinite', 'isinf', 'isnan', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2',
#            'modf', 'nan', 'pow', 'radians', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'tau', 'trunc', 'round',
#             'abs','+', '-', '*', '/', '%', '^', '//', '(', ')', 'e', 'pi']
#
# ERROR_CASES = [
    # "",
    # "+",
    # "1-",
    # "1 2",
    # "==7",
    # "1 + 2(3 * 4))",
    # "((1+2)",
    # "1 + 1 2 3 4 5 6 ",
    # "abs",
    # "(((((",
    # "------",
    # "5 > = 6",
    # "5 / / 6",
    # "6 < = 6",
    # "6 * * 6",
    #
    # "log100(100)",
    # "log10(100)",
    # "log1p(100)",
    # "log(100)",
    # "10*e^0*log10(.4 -5/ -0.1-10) - -abs(-53/10) + -5"
#     "pow(2, 3, 4)",
# ]
# import re
#
# def check_error(formula):
#
#     if not formula:
#         print('Error: not value')
#     else:
#         if formula[-1] in OPERATORS:
#             print('Error Znak: ', formula)
#         if formula[1:2] in '^%*/=':
#             print('Error StartZnak: ', formula)
#
#         if re.search(r'\d\s\d', formula):
#             print('Error space1: ', formula)
#
#         if formula.count('(')!=formula.count(')'):
#             print('Error brackets: ', formula)
#
#         if formula in OPERATORS:
#             print('Error ', formula)
#
#         if re.search(r'[*,/,<,>,%,^,=]\s[*,/,<,>,%,^,=]', formula):
#             print('Error space3: ', formula)
#
#         if re.search(r'log[1][0,p][^(]', formula):
#             print('Error space: ', formula)
#
#
#
#         for name_func in OPERATORS:
#             if name_func.isalpha() or name_func in ['log1p', 'log10', 'atan2', 'expm1', 'log2']:
#                 name_func_bracket = '{}('.format(name_func)
#
#                 if name_func_bracket in formula:
#                     for value in formula.split(name_func_bracket)[1:]:
#                         count_brackets = 0
#                         func_expression = []
#                         for key in value:
#                             if key == ')' and not count_brackets:
#                                 break
#                             elif key == ')':
#                                 count_brackets -= 1
#                             elif key == '(':
#                                 count_brackets += 1
#                             func_expression.append(key)
#
#
#                         if func_expression.count(',') > 1 and name_func in ['pow','log']:
#
#                             return 'ERROR 1param {}'.format(name_func)
#                         elif func_expression.count(',') > 0 and not name_func in ['pow','log']:
#                             print(name_func)
#                             return 'ERROR 2param {}'.format(name_func)
#
#
#
# formula='pow(2, 3, 4)'
# print(check_error(formula))

from math import *

OPERATORS_func=['acos', 'acosh', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'ceil', 'copysign', 'cos', 'cosh', 'degrees',
           'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'gcd',
           'hypot', 'inf', 'isclose', 'isfinite', 'isinf', 'isnan', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2',
           'modf', 'nan', 'pow', 'radians', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'tau', 'trunc', 'round',
            'abs','e', 'pi']

oper=[
"acos(1)",
"acosh(1)",
"asin(1)",
"asinh(1)",
"atan(1)",
"atanh(0)",
"ceil(1)",
"cos(1)",
"cosh(1)",
"degrees(1)",
"erf(1)",
"erfc(1)",
"exp(1)",
"expm1(1)",
"fabs(1)",
"factorial(1)",
"floor(1)",
"frexp(1)",
"gamma(1)",
"isfinite(1)",
"isinf(1)",
"isnan(1)",
"lgamma(1)",
"log10(1)",
"log1p(1)",
"log2(1)",
"modf(1)",
"radians(1)",
"sin(1)",
"sinh(1)",
"sqrt(1)",
"tan(1)",
"tanh(-2)",
"trunc(1)",
"round(1)",
"abs(1)",


"fsum([1,1])", # pizdec
"log(10,10)",
"atan2(0,1)",  # 2argument
"copysign(1,0)",  # 2argument
"fmod(1,1)",  # 2argument
"gcd(1,0)",  # 2argument
"hypot(3, 4)",  # 2argument
"isclose(1,2)",  # 2argument
"ldexp(1,2)",  # 2argument
"pow(1,2)",  # 2argument


"e",
"pi",
"inf",
"nan",
"tau",

]
#
# for data in oper:
#     print(data, eval(data))



def format_function_fsum(formula):

    count_brackets = 0
    count_brackets_square = 0
    count_arguments = []
    add_argument = []

    for key in formula.split('fsum([',1)[1:][0]:
        if key=="]" and not count_brackets_square:
            break

        if key == ',' and not count_brackets:
            count_arguments.append(''.join(add_argument))
            add_argument=[]
        else:
            add_argument.append(key)


        if key == ']':
            count_brackets_square -= 1
        elif key == '[':
            count_brackets_square += 1
        elif key == ')':
            count_brackets -= 1
        elif key == '(':
            count_brackets += 1

    if len(count_arguments)>0:
        count_arguments.append(''.join(add_argument))

    print(','.join(count_arguments))

    result_count=0
    for argument in count_arguments:
        result_count+=int(argument)  #dgdfghdfgdfgdfg

    replace_expression = "fsum([{}])".format(','.join(count_arguments), 1)

    result_formula = formula

    result_formula = result_formula.replace(replace_expression, str(result_count), 1)

    return result_formula


print(format_function_fsum(formula='10+fsum([1,2,3,4])+10'))