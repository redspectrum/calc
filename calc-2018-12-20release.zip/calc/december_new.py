

import argparse
import math
import re

OPERATORS = {'+': (1, lambda x, y: x + y),
             '-': (1, lambda x, y: x - y),
             '*': (2, lambda x, y: x * y),
             '/': (2, lambda x, y: x / y),
             '//': (2, lambda x, y: x // y),
             '%': (2, lambda x, y: x % y),
             '^': (4, lambda x, y: x ** y),
             'atan2': (3, lambda x, y: math.atan2(x, y)),
             'copysign': (3, lambda x, y: math.copysign(x, y)),
             'fmod': (3, lambda x, y: math.fmod(x, y)),
             'gcd': (3, lambda x, y: math.gcd(x, y)),
             'hypot': (3, lambda x, y: math.hypot(x, y)),
             'isclose': (3, lambda x, y: math.isclose(x, y)),
             'ldexp': (3, lambda x, y: math.ldexp(x, y)),
             'pow': (3, lambda x, y: math.pow(x, y)),
             'log': (3, lambda x, y: math.log(x, y)),


# "fsum([1,1])", # pizdec
# "atan2(0,1)",  # 2argument
# "copysign(1,0)",  # 2argument
# "fmod(1,1)",  # 2argument
# "gcd(1,0)",  # 2argument
# "hypot(3, 4)",  # 2argument
# "isclose(1,2)",  # 2argument
# "ldexp(1,2)",  # 2argument
# "pow(1,2)",  # 2argument


             'acos': (3, lambda x: math.acos(x)),
             'acosh': (3, lambda x: math.acosh(x)),
             'asin': (3, lambda x: math.asin(x)),
             'asinh': (3, lambda x: math.asinh(x)),
             'atan': (3, lambda x: math.atan(x)),
             'atanh': (3, lambda x: math.atanh(x)),
             'ceil': (3, lambda x: math.ceil(x)),
             'cos': (3, lambda x: math.cos(x)),
             'cosh': (3, lambda x: math.cosh(x)),
             'degrees': (3, lambda x: math.degrees(x)),
             'erf': (3, lambda x: math.erf(x)),
             'erfc': (3, lambda x: math.erfc(x)),
             'exp': (3, lambda x: math.exp(x)),
             'expm1': (3, lambda x: math.expm1(x)),
             'fabs': (3, lambda x: math.fabs(x)),
             'factorial': (3, lambda x: math.factorial(x)),
             'floor': (3, lambda x: math.floor(x)),
             'frexp': (3, lambda x: math.frexp(x)),
             'gamma': (3, lambda x: math.gamma(x)),
             'isfinite': (3, lambda x: math.isfinite(x)),
             'isinf': (3, lambda x: math.isinf(x)),
             'isnan': (3, lambda x: math.isnan(x)),
             'lgamma': (3, lambda x: math.lgamma(x)),
             'log10': (3, lambda x: math.log10(x)),
             'log1p': (3, lambda x: math.log1p(x)),
             'log2': (3, lambda x: math.log2(x)),
             'modf': (3, lambda x: math.modf(x)),
             'radians': (3, lambda x: math.radians(x)),
             'sin': (3, lambda x: math.sin(x)),
             'sinh': (3, lambda x: math.sinh(x)),
             'sqrt': (3, lambda x: math.sqrt(x)),
             'tan': (3, lambda x: math.tan(x)),
             'tanh': (3, lambda x: math.tanh(x)),
             'trunc': (3, lambda x: math.trunc(x)),
             'round': (3, lambda x: round(x)),
             'abs': (3, lambda x: abs(x)),

# "acos(1)",
# "acosh(1)",
# "asin(1)",
# "asinh(1)",
# "atan(1)",
# "atanh(0)",
# "ceil(1)",
# "cos(1)",
# "cosh(1)",
# "degrees(1)",
# "erf(1)",
# "erfc(1)",
# "exp(1)",
# "expm1(1)",
# "fabs(1)",
# "factorial(1)",
# "floor(1)",
# "frexp(1)",
# "gamma(1)",
# "isfinite(1)",
# "isinf(1)",
# "isnan(1)",
# "lgamma(1)",
# "log10(1)",
# "log1p(1)",
# "log2(1)",
# "modf(1)",
# "radians(1)",
# "sin(1)",
# "sinh(1)",
# "sqrt(1)",
# "tan(1)",
# "tanh(-2)",
# "trunc(1)",
# "round(1)",
# "abs(1)",

             }



constant = {'pi': math.pi,
            'e': math.e,
            'inf':math.inf,
            'nan':math.nan,
            'tau':math.tau,
       }



OPERATORS_func=['acos', 'acosh', 'asin', 'asinh', 'atan', 'atan2', 'atanh', 'ceil', 'copysign', 'cos', 'cosh', 'degrees',
           'erf', 'erfc', 'exp', 'expm1', 'fabs', 'factorial', 'floor', 'fmod', 'frexp', 'fsum', 'gamma', 'gcd',
           'hypot', 'inf', 'isclose', 'isfinite', 'isinf', 'isnan', 'ldexp', 'lgamma', 'log', 'log10', 'log1p', 'log2',
           'modf', 'nan', 'pow', 'radians', 'sin', 'sinh', 'sqrt', 'tan', 'tanh', 'tau', 'trunc', 'round',
            'abs','+', '-', '*', '/', '%', '^', '//', '(', ')', 'e', 'pi']

OPERATORS_double = ['+', '-', '*', '/', '%', '^', '//','%','atan2','copysign','fmod','gcd','hypot','isclose',
                    'ldexp','pow', 'log']


OPERATORS_compare = {'==': (lambda x, y: x == y),
                     '>=': (lambda x, y: x >= y),
                     '<=': (lambda x, y: x <= y),
                     '!=': (lambda x, y: x != y),
                     '<': (lambda x, y: x < y),
                     '>': (lambda x, y: x > y),
                     }


def main_count(formula):


    def check_error(formula):

        if not formula:
            return "ERROR: no value"
        else:

            if formula[-1] in OPERATORS:
                return "ERROR: syntax error"
            if formula[0] in '^%*/= |\\':
                return "ERROR: syntax error"

            if re.search(r'\d\s\d', formula):
                return "ERROR: syntax error"

            if formula.count('(') != formula.count(')'):
                return "ERROR: brackets are not balanced"

            if formula in OPERATORS:
                return "ERROR: no function arguments"

            if '()'in formula:
                return "ERROR: no function arguments"

            if re.search(r'[*,/,<,>,%,^,=]\s[*,/,<,>,%,^,=]', formula):
                return "ERROR: syntax error in statements"

            if re.search(r'log[1,2][0,p][^(]', formula):
                return "ERROR: unknown function"


            for name_func in OPERATORS:
                if name_func.isalpha() or name_func in ['log1p', 'log10', 'atan2', 'expm1', 'log2']:
                    name_func_bracket = '{}('.format(name_func)

                    if formula.split(name_func_bracket)[1:]==')':
                        return "ERROR: function arguments are not balanced"

                    if name_func_bracket in formula:

                        for value in formula.split(name_func_bracket)[1:]:
                            count_brackets = 0

                            count_arguments = 0
                            for key in value:
                                if key == ',' and not count_brackets:
                                    count_arguments+=1

                                if key == ')' and not count_brackets:
                                    break
                                elif key == ')':
                                    count_brackets -= 1
                                elif key == '(':
                                    count_brackets += 1

                            if count_arguments > 1:
                                return "ERROR: function arguments are not balanced"
                            elif (count_arguments > 1 or count_arguments==0) and name_func=='pow':
                                return "ERROR: function arguments are not balanced"
                            elif count_arguments==0 and name_func in ['atan2', 'copysign', 'fmod', 'gcd', 'hypot',
                                                                           'isclose', 'ldexp','pow']:
                                return "ERROR: function arguments are not balanced"
                            elif count_arguments > 0 and not name_func in ['atan2', 'copysign', 'fmod', 'gcd', 'hypot',
                                                                           'isclose', 'ldexp','pow', 'log']:
                                return "ERROR: function arguments are not balanced"


    def function_format(formula, name_function):
        # print(formula, name_function)

        result_formula = formula


        first_argument = []
        second_argument = []
        count_argument = True
        count_bracket = 0
        for key in (name_function).join(formula.split('{}'.format(name_function))[1:]):

            if key == '(':
                count_bracket += 1
            if key == ')':
                count_bracket -= 1
            if key == ',':
                first_argument.pop(0)
                count_argument = False

            if key == ')' and not count_bracket and not count_argument:
                break
            elif key == ')' and not count_bracket:
                first_argument.append(key)
                break

            elif count_argument:
                first_argument.append(key)

            else:
                if key != ',':
                    second_argument.append(key)

        #print(''.join(first_argument), ''.join(second_argument))

        if not second_argument:
            second_argument.append('e')
            replace_expression = "{}{}".format(name_function, ''.join(first_argument),1)
        else:
            replace_expression = "{}({},{})".format(name_function, ''.join(first_argument),
                                                    ''.join(second_argument),1)



        x = main_count(''.join(first_argument))
        y = main_count(''.join(second_argument))

        if name_function=='gcd':
            x=int(x)
            y=int(y)

        result_function = OPERATORS[name_function][1](x, y)

        result_formula = result_formula.replace(replace_expression, str(result_function),1)


        # check twice function FE: pow pow
        if name_function=='log':
            if 'log(' in result_formula:
                result_formula=function_format(result_formula, name_function)
        else:
            if name_function in result_formula:
                result_formula=function_format(result_formula, name_function)

        return result_formula

    def format_degree(formula):
        if '^^' in formula:
            raise SyntaxError
        result_formula=[]

        for i,key in enumerate(formula.split('^')):

            result_formula.append(key)
            if i != len(formula.split('^'))-1:
                result_formula.append('^'*(i+1))
                OPERATORS.update({'^'*(i+1): (4+i, lambda x, y: x ** y)})
                OPERATORS_double.append('^'*(i+1))
                OPERATORS_func.append('^'*(i+1))

        return ''.join(result_formula)

    def function_format_degree_replace_function(formula):
        # replace 1^sin(pi) into==> 1^(sin(pi))

        expression = []
        count_argument = False
        count_bracket = 0
        for i, key in enumerate(formula):

            if key == '(':
                count_bracket += 1
            elif key == ')':
                count_bracket -= 1

            if count_argument:
                expression.append(key)

            if key == ')' and not count_bracket and count_argument:
                break

            if key == '^' and formula[i + 1].isalpha():
                count_argument = True

        formula = formula.replace("{}".format(''.join(expression)), "({})".format(''.join(expression)), 1)

        count = False
        for i, key in enumerate(formula):
            if key == '^' and formula[i + 1].isalpha():
                count = True
                break

        if count:
            formula = function_format_degree_replace_function(formula)

        return formula

    def replace_degree_negative_number(formula):

        # replace  ^-5 ==> into ^(0-5)
        # ^ -e == > into ^(0 - e)
        # ^ -cos() == > into ^(0 - cos())
        # ^ -(1+2) == > into ^(0 - (1+2))

        expression=[]
        count=False
        bracket_count = 0
        for i,key in enumerate(formula):


            if count:
                if key == ')' and not bracket_count:
                    expression.append(key)
                    break
                elif key == ')':
                    bracket_count -= 1
                elif key == '(':
                    bracket_count += 1

                if expression and (key in OPERATORS_double or key in OPERATORS_compare) and not bracket_count:
                    break
                else:
                    expression.append(key)


            if key=='^' and formula[i+1]=='-':
                count=True


        # replace only first expression
        formula = formula.replace(("^{}".format(''.join(expression)))  ,    "^(0{})".format(''.join(expression)),1)

        if '^-' in formula:
            formula=replace_degree_negative_number(formula)

        return formula


    def delete_same_signs(formula):

        new_data = []

        # delete backspace
        formula=formula.replace(' ', '')


        formula='(0-'.join(formula.split('(-'))


        for name_function in ['pow', 'log(', 'copysign', 'ldexp', 'atan2', 'hypot','fmod','gcd']:
            if name_function in formula:
                # because we use only log (without log10,log1p)
                if name_function=='log(':
                    name_function='log'
                formula=function_format(formula, name_function)


        for _ in formula:
            if '^' in formula and formula[formula.index('^')+1].isalpha():
                formula = function_format_degree_replace_function(formula)
                break


        if formula.count("^") > 1:
            formula=format_degree(formula)

        new_data.append(formula[0])

        for token in formula[1:]:
            if new_data[-1] == '+' and token == '-':
                new_data[-1] = '-'
            elif new_data[-1] == '-' and token == '+':
                new_data[-1] = '-'
            elif new_data[-1] == '-' and token == '-':
                new_data[-1] = '+'
            elif new_data[-1] == '+' and token == '+':
                new_data[-1] = '+'
            else:
                new_data.append(token)
        if new_data[0]=='-':
            new_data.insert(0,'0')
        if new_data[0]=='+':
            new_data.pop(0)

        formula = ''.join(new_data)

        # replace 5/-1 into 5*(-1)/1
        formula = formula.replace('/-','*(0-1)/')
        formula = formula.replace('*-','*(0-1)*')

        if '^-' in formula:
            formula=replace_degree_negative_number(formula)

        return formula

    def parse(formula_string):
        # print(formula_string)

        stack = []

        for i, key in enumerate(formula_string):

            if key in '1234567890.':

                # check log10 log1p log2
                if len(stack) > 2 and ''.join(stack[:3])=='log':

                    stack.append(key)
                    if ''.join(stack) in OPERATORS_func:
                        yield ''.join(stack)
                        stack = []


                elif stack and (stack[0] not in '1234567890.'):
                    yield ''.join(stack)
                    stack = []
                    stack.append(key)
                else:
                    stack.append(key)

            else:
                if key in '()':
                    if stack and (stack[0] in '1234567890.'):
                        yield float(''.join(stack))
                    elif stack:
                        yield ''.join(stack)

                    stack = []
                    stack.append(key)


                elif len(stack) > 2 and ''.join(stack[:3])=='log':
                    stack.append(key)
                    if ''.join(stack) in OPERATORS_func:
                        yield ''.join(stack)
                        stack = []


                elif stack and stack[0] in '1234567890.':
                    yield float(''.join(stack))
                    stack = []
                    stack.append(key)

                else:

                    if ''.join(stack) + key in OPERATORS_func:
                        stack.append(key)

                    elif ''.join(stack) in constant:
                        yield constant.get(''.join(stack))
                        stack = []
                        stack.append(key)


                    elif ''.join(stack) in OPERATORS_func:

                        yield ''.join(stack)
                        stack = []
                        stack.append(key)
                    else:
                        stack.append(key)
        else:

            if stack and (stack[0] in '1234567890.'):
                yield float(''.join(stack))
            elif ''.join(stack) in constant:
                yield constant.get(''.join(stack))
            else:
                yield ''.join(stack)


    def shunting_yard(parsed_formula):
        #print(list(parsed_formula))


        stack = []
        for token in parsed_formula:
            if token in constant:
                token = constant.get(''.join(token))


            if token in OPERATORS:
                while stack and stack[-1] != "(" and OPERATORS[token][0] <= OPERATORS[stack[-1]][0]:
                    yield stack.pop()
                stack.append(token)
            elif token == ")":
                while stack:
                    x = stack.pop()
                    if x == "(":
                        break
                    yield x
            elif token == "(":
                stack.append(token)
            else:
                yield token
        while stack:
            yield stack.pop()


    def calc(polish):
        #print(list(polish))

        stack = []

        for token in polish:

            if token in OPERATORS:

                if token in OPERATORS_double:
                    # print('token,stack ',token,stack)

                    y, x = stack.pop(), stack.pop()

                    stack.append(OPERATORS[token][1](x, y))
                else:

                    x = stack.pop()

                    stack.append(OPERATORS[token][1](x))

            else:
                stack.append(token)


        return stack[0]

    def check_compare(formula):

        for compare in OPERATORS_compare:
            if compare in formula:
                return OPERATORS_compare.get(compare)(
                    main_count(formula.split(compare)[0]),
                    main_count(formula.split(compare)[1]))

        # start calculation
        return calc(shunting_yard(parse(delete_same_signs(formula))))


    return check_error(formula) if check_error(formula) else check_compare(formula)



if __name__ == '__main__':

    data=[
    'gcd(1,1)',
    'sin()',
          ]

    for value in data:
        print(main_count(value))

